---
title: 0. 参考资料
date: 2018-11-01 00:38:11
tags: list_array_tt
categories: Runtime
toc: true
---


## 参考资料

1. [Draveness git地址](https://github.com/Draveness/analyze)
2. [Classes and Metaclasses](http://www.sealiesoftware.com/blog/archive/2009/04/14/objc_explain_Classes_and_metaclasses.html)
3. [类型编码](https://developer.apple.com/library/mac/documentation/Cocoa/Conceptual/ObjCRuntimeGuide/Articles/ocrtTypeEncodings.html)
4. [Type Encodings](http://nshipster.cn/type-encodings/)
5. [Tagged Pointer](https://en.wikipedia.org/wiki/Tagged_pointer)
6. [Xcode 10 下如何调试objc4-723](https://www.jianshu.com/p/9e0fc8295c4b)



